# <p align="center" style="color:#cb3349" >👨‍💻 سـورس مــاكــس

# <p align="center" style="color:#cb3349" > شروحات عن السورس ادخل الى قناة السورس

# <p align="center" style="color:#cb3349" > [اصـــغـــط هــنـــا لــلــدخــول الــى الــقــنــاة](https://telegram.me/hlh_313) <br>

# <p align="center"> كود تنصيب السورس 🖇

 # <p align="center" style="color:#cb3349" > `git clone https://github.com/MAXTELE/MAX.git ;cd MAX;chmod +x ins;./ins`    

# <p align="center"> بعد انتهاء عمليه تثبيت السورس 🚸

# <p align="center" style="color: #14635c;" >يطلب توكن البوت دخل توكن واضغط انتر ┊📊
 
# <p align="center" style="color:#cb3349" > وراها راح يطلب منك معرف المطور الاساسي دخله واضغط انتر ┊⚙️


# <p align="center" style="color:#cb3349" > 💬┊للمشاكل والاسفسار والاقتراحات :
  
# <p align="center" style="color:#cb3349" > [حـســونــي](https://telegram.me/hlh313) <br>
  
  
# <p align="center" style="color:#cb3349" > [قــنــاة الــســورس](https://telegram.me/hlh_313) <br>
